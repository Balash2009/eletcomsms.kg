﻿<?php

header('Content-type: text/html; charset=utf-8');

/**
 * Отправка POST-запроса.
 */
function post_content($url, $postdata) {
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_ENCODING, "");
	curl_setopt($ch, CURLOPT_TIMEOUT, 120);
	/** Поддержка keep-alive. */
	/** 
	curl_setopt($ch, CURLOPT_TCP_KEEPALIVE, 1);
	curl_setopt($ch, CURLOPT_TCP_KEEPIDLE, 120);
	curl_setopt($ch, CURLOPT_TCP_KEEPINTVL, 60);
	*/
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);

	$content = curl_exec( $ch );
	$err = curl_errno($ch);
	$errmsg = curl_error($ch);
	$header = curl_getinfo($ch);
	curl_close($ch);

	$header['errno'] = $err;
	$header['errmsg'] = $errmsg;
	$header['content'] = $content;
	return $header;
}

/**  
 * Логин для доступа к платформе smspro.nikita.kg.  
 * */
$login = 'login';
/** 
 * Пароль для доступа к платформе smspro.nikita.kg. 
 * */
$password = 'password';
/** 
 * Уникальный идентификатор транзакции. Для каждой отправки он должен быть уникальным.
 * Используя этот ID можно получить отчет о доставке сообщения.
 * */
$transactionId = 'U4B4m1za';
/**
 * Имя отправителя - должно быть согласовано с администратором smspro.nikita.kg
 * */
$sender = 'SMSPRO.KG';
/** 
 * Текст СМС-сообщения - текст на русском или латинице любой длины (до 800 знаков). 
 * В случае необходимости платформа smspro.nikita.kg автоматически разделит текст на несколько сообщений. 
 * */
$text = 'test';
/** 
 * Номер телефона получателя СМС в формате 996ххххххххх. 
 * В одной транзакции отправки может быть указано и более 1го телефона.
 * */
$phone = '996550403993';

$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>".
	"<message>".
		"<login>$login</login>".
		"<pwd>$password</pwd>".
		"<id>$transactionId</id>".
		"<sender>$sender</sender>".
		"<text>$text</text>".
		"<phones>".
		"<phone>$phone</phone>".
		"</phones>". 
	"</message>";

/**
 * Отправка сообщения с указанием времени отправки в формате YYYYMMDDHHMMSS.
 * */
/**
$time = '20240101123000';
$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>".
	"<message>".
		"<login>$login</login>".
		"<pwd>$password</pwd>".
		"<id>$transactionId</id>".
		"<sender>$sender</sender>".
		"<text>$text</text>".
		"<time>$time</time>".
		"<phones>".
		"<phone>$phone</phone>".
		"</phones>". 
	"</message>";	
*/

/**
 * Отправка сообщения на несколько номеров.
 * */

/**
$phones = ['996550403993', '996779377888'];
$phones_xml = "<phones>";
foreach ($phones as $phone) {
	$phones_xml .= "<phone>$phone</phone>";
}
$phones_xml .= "</phones>";
$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>".
	"<message>".
		"<login>$login</login>".
		"<pwd>$password</pwd>".
		"<id>$transactionId</id>".
		"<sender>$sender</sender>".
		"<text>$text</text>".
		$phones_xml.
	"</message>";
*/

/**
 * Отправка тестового сообщения, сообщение не будет отправлено фактически и не будет тарифицировано.
 * */
/** 
$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>".
	"<message>".
		"<login>$login</login>".
		"<pwd>$password</pwd>".
		"<id>$transactionId</id>".
		"<sender>$sender</sender>".
		"<text>$text</text>".
		"<phones>".
		"<phone>$phone</phone>".
		"</phones>".
		"<test>1</test>". 
	"</message>";	
*/
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Страница отправки SMS через шлюз smspro.nikita.kg</title>
</head>
<body>
<h1>Страница отправки SMS через шлюз smspro.nikita.kg</h1>
<hr>
<h4>Отправляемый XML-запрос:</h4>
<code>
	<?=htmlspecialchars($xml); ?>
</code>
<h4>Результат:</h4>
<?php
try {
	$url = "http://smspro.nikita.kg/api/message";
	$result = post_content($url, $xml);
	$html = $result['content'];
	$responseXml = htmlspecialchars($html);
?>
Ответ сервера:<br>
<code><?=$responseXml ?></code>
<?php    	
} catch (Exception $e) {
	echo 'Caught exception: ',  $e->getMessage(), "\n";
	var_dump($e->getTrace());
}
?>
</body>
</html>