﻿<?php

header('Content-type: text/html; charset=utf-8');

/**
 * Отправка POST-запроса.
 */
function post_content($url, $postdata) {
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_ENCODING, "");
	curl_setopt($ch, CURLOPT_TIMEOUT, 120);
	/** Поддержка keep-alive. */
	/** 
	curl_setopt($ch, CURLOPT_TCP_KEEPALIVE, 1);
	curl_setopt($ch, CURLOPT_TCP_KEEPIDLE, 120);
	curl_setopt($ch, CURLOPT_TCP_KEEPINTVL, 60);
	*/
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);

	$content = curl_exec( $ch );
	$err = curl_errno($ch);
	$errmsg = curl_error($ch);
	$header = curl_getinfo($ch);
	curl_close($ch);

	$header['errno'] = $err;
	$header['errmsg'] = $errmsg;
	$header['content'] = $content;
	return $header;
}

/**  
 * Логин для доступа к платформе smspro.nikita.kg.  
 * */
$login = 'login';
/** 
 * Пароль для доступа к платформе smspro.nikita.kg. 
 * */
$password = 'password';
/** 
 * ID транзакции, который использовался при отправке СМС.
 * */
$transactionId = 'U4B4m1za';

$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>".
	"<dr>".		
	"<login>$login</login>".
	"<pwd>$password</pwd>".
	"<id>$transactionId</id>".
	"</dr>";

/**
 * Если отправка производилась сразу по нескольким телефонам, то можно запросить отчет для одного конкретного телефона.
 * */
/** 
$phone = '996550403993';
$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>".
	"<dr>".		
	"<login>$login</login>".
	"<pwd>$password</pwd>".
	"<id>$transactionId</id>".
	"<phone>$phone</phone>".
	"</dr>";
*/
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Страница получения отчета о доставке отправленного СМС через шлюз smspro.nikita.kg</title>
</head>
<body>
<h1>Страница получения отчета о доставке отправленного СМС через шлюз smspro.nikita.kg</h1>
<hr>
<h4>Отправляемый XML-запрос:</h4>
<code>
	<?=htmlspecialchars($xml); ?>
</code>
<h4>Результат:</h4>
<?php
try {
	$url = "http://smspro.nikita.kg/api/dr";
	$result = post_content($url, $xml);
	$html = $result['content'];
	$responseXml = htmlspecialchars($html);
?>
Ответ сервера:<br>
<code><?=$responseXml ?></code>
<?php    	
} catch (Exception $e) {
	echo 'Caught exception: ',  $e->getMessage(), "\n";
	var_dump($e->getTrace());
}
?>
</body>
</html>