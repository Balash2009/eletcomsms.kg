const https = require('https');

/**  
 * Логин для доступа к платформе smspro.nikita.kg.  
 * */
const login = 'login';
/** 
 * Пароль для доступа к платформе smspro.nikita.kg. 
 * */
const password = 'password';
/** 
 * ID транзакции, который использовался при отправке СМС.
 * */
const transactionId = 'U4B4m1za';

const xmlData = `
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<dr>
    <login>${login}</login>
    <pwd>${password}</pwd>
    <id>${transactionId}</id>
</dr>
`;

/**
 * Если отправка производилась сразу по нескольким телефонам, то можно запросить отчет для одного конкретного телефона.
 * */
/**
const phone = '996550403993';
const xmlData = `
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<dr>
    <login>${login}</login>
    <pwd>${password}</pwd>
    <id>${transactionId}</id>
    <phone>${phone}</phone>
</dr>
`;
*/

const options = {
    hostname: 'smspro.nikita.kg',
    path: '/api/dr',
    method: 'POST',
    headers: {
        'Content-Type': 'application/xml',
        'Content-Length': Buffer.byteLength(xmlData),
    },
    /** Поддержка keep-alive. */
    agent: new https.Agent({ keepAlive: true })
};

const req = https.request(options, res => {
    let responseData = '';

    res.on('data', chunk => {
        responseData += chunk;
    });

    res.on('end', () => {
        console.log('Ответ сервера: ', responseData);
    });
});

req.write(xmlData);
req.end();