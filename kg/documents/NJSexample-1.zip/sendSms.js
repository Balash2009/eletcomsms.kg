const https = require('https');

/**  
 * Логин для доступа к платформе smspro.nikita.kg.  
 * */
const login = 'login';
/** 
 * Пароль для доступа к платформе smspro.nikita.kg. 
 * */
const password = 'password';
/** 
 * Уникальный идентификатор транзакции. Для каждой отправки он должен быть уникальным.
 * Используя этот ID можно получить отчет о доставке сообщения.
 * */
const transactionId = 'U4B4m1za';
/**
 * Имя отправителя - должно быть согласовано с администратором smspro.nikita.kg
 * */
const sender = 'SMSPRO.KG';
/** 
 * Текст СМС-сообщения - текст на русском или латинице любой длины (до 800 знаков). 
 * В случае необходимости платформа smspro.nikita.kg автоматически разделит текст на несколько сообщений. 
 * */
const text = 'test';
/** 
 * Номер телефона получателя СМС в формате 996ххххххххх. 
 * В одной транзакции отправки может быть указано и более 1го телефона.
 * */
const phone = '996550403993';

const xmlData = `
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<message>
    <login>${login}</login>
    <pwd>${password}</pwd>
    <id>${transactionId}</id>
    <sender>${sender}</sender>
    <text>${text}</text>
    <phones>
        <phone>${phone}</phone>
    </phones>
</message>
`;

/**
 * Отправка сообщения с указанием времени отправки в формате YYYYMMDDHHMMSS.
 * */
/**
const time = '20240101123000';
const xmlData = `
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<message>
    <login>${login}</login>
    <pwd>${password}</pwd>
    <id>${transactionId}</id>
    <sender>${sender}</sender>
    <text>${text}</text>
    <time>${time}</time>
    <phones>
        <phone>${phone}</phone>
    </phones>
</message>
`;
*/

/**
 * Отправка сообщения на несколько номеров.
 * */
/**
const phones = ['996550403993', '996779377888'];
const phonesXml = '';
phones.forEach(phone => {
    phonesXml += `<phone>${phone}</phone>\n`;
});
const xmlData = `
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<message>
    <login>${login}</login>
    <pwd>${password}</pwd>
    <id>${transactionId}</id>
    <sender>${sender}</sender>
    <text>${text}</text>
    <phones>
        ${phonesXml}
    </phones>
</message>
`;
*/

/**
 * Отправка тестового сообщения, сообщение не будет отправлено фактически и не будет тарифицировано.
 * */
/**
const xmlData = `
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<message>
    <login>${login}</login>
    <pwd>${password}</pwd>
    <id>${transactionId}</id>
    <sender>${sender}</sender>
    <text>${text}</text>
    <phones>
        <phone>${phone}</phone>
    </phones>
    <test>1</test>
</message>
`;
*/

const options = {
    hostname: 'smspro.nikita.kg',
    path: '/api/message',
    method: 'POST',
    headers: {
        'Content-Type': 'application/xml',
        'Content-Length': Buffer.byteLength(xmlData),
    },
    /** Поддержка keep-alive. */
    agent: new https.Agent({ keepAlive: true })
};

const req = https.request(options, res => {
    let responseData = '';

    res.on('data', chunk => {
        responseData += chunk;
    });

    res.on('end', () => {
        console.log('Ответ сервера: ', responseData);
    });
});

req.write(xmlData);
req.end();